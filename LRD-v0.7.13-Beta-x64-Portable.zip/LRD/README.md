# LRD – Local Record Desk 64 Bit – v0.7.13 Beta

## v0.7.11 Beta – LRD ist jetzt eine 64-Bit-Anwendung

LRD verwendet ab dieser Version **Python 3.10–3.13 64 Bit** als Entwicklungs- und Build-Ziel. Der fruehere 32-Bit-Zwang war nur fuer den direkten Zugriff auf die alte Access/Jet-MDB erforderlich. Da LRD selbst inzwischen ausschliesslich SQLite verwendet und der private MDB→CSV-Konverter getrennt ist, besteht diese Abhaengigkeit nicht mehr.

Die oeffentliche LRD-Anwendung ist damit 64 Bit. Das private Werkzeug **LRD_MDB_to_CSV_Private** bleibt bei Bedarf separat 32 Bit, damit es weiterhin mit dem alten 32-Bit-Access/Jet-Treiber arbeiten kann.

### Start aus dem Quellpaket

1. Python 3.13 **64 Bit** installieren.
2. Einmal `install_64bit.bat` ausfuehren.
3. LRD mit `run_64bit.bat` starten.
4. `diagnose_64bit.bat` zeigt die tatsaechlich verwendete Python-Bitbreite, Tcl/Tk und SQLite an.

Die SQLite-Datenbank ist plattformneutral hinsichtlich 32/64 Bit. Eine vorhandene `LRD.sqlite` bzw. `MUSICDB.sqlite` kann unveraendert weiterverwendet werden.

### Nuitka-Build 64 Bit

`build_exe_64bit.bat` erzeugt zuerst einen Standalone-Build. `build_onefile_64bit.bat` erzeugt spaeter die einzelne `LRD.exe`. Beide Buildwege:

- pruefen explizit auf 64-Bit-Python,
- aktivieren das Nuitka-Plugin `tk-inter`, damit Tcl/Tk mitgeliefert wird,
- verwenden `--zig`, damit fuer Python 3.10–3.13 64 Bit kein separat installiertes Visual Studio erforderlich ist,
- erlauben Nuitka benoetigte Build-Hilfsprogramme automatisch in den lokalen Nuitka-Cache zu laden,
- verwenden die zentrale Programmversion aus `musicdb/version.py`.

Die fertige `LRD.exe` benoetigt weder Python noch einen Access-/Jet-Treiber auf dem Zielrechner.


## v0.7.9 Beta – sauberer Erststart ohne vorhandene Datenbank

LRD kann jetzt auf einem neuen Rechner **ohne vorhandene SQLite-Datenbank** gestartet werden. Beim ersten Start erscheint eine kleine Auswahl mit Deutsch/English:

- **Neue leere Datenbank erstellen…** – legt eine neue LRD-SQLite-Datenbank am gewünschten Speicherort an.
- **Vorhandene LRD-Datenbank öffnen…** – öffnet eine bereits vorhandene `.sqlite`/`.db`-Datei.
- **Beenden** – beendet LRD ohne Änderungen.

Beim Anlegen einer neuen Datenbank kann optional ein kleiner Musterbestand mit fünf Beispieldatensätzen erzeugt werden. Die Muster sind normale Datensätze und können anschließend bearbeitet oder gelöscht werden.

Nach dem Anlegen einer neuen Datenbank fragt LRD optional, ob sofort der CSV-Importassistent geöffnet werden soll. Damit ist auch die Erstinstallation für Anwender ohne vorhandene Datenbank vollständig möglich. Die zuletzt gewählte Datenbank wird gemerkt; bei einer portablen, beschreibbaren Installation in `config.local.json` neben LRD, andernfalls unter `%LOCALAPPDATA%\LRD\config.local.json`.

Neue Datenbanken heißen standardmäßig `LRD.sqlite`. Vorhandene Entwicklungsdatenbanken mit dem früheren Namen `MUSICDB.sqlite` werden weiterhin automatisch erkannt. Die Datenbankerstellung gehört zum normalen LRD-Programm und ist unabhängig vom privaten MDB→CSV-Werkzeug.


## v0.7.6 Beta – komfortabler CSV-Import und -Export

LRD besitzt nun einen eigenständigen Datenübertragungsbereich unter **Daten**. Die Architektur ist adapterbasiert: CSV ist der erste Adapter; ein späterer Discogs-Import/-Export kann als eigener Adapter ergänzt werden, ohne die interne Datenbankpflege neu aufzubauen.

#
### Fortschrittsanzeige beim Import

Testlauf und echter CSV-Import zeigen einen Fortschrittsbalken, Prozentwert und Datensatzzähler. Auch die Vorbereitung der Duplikatprüfung und eine Sicherung vor dem Import werden als eigener Arbeitsschritt angezeigt. Bei normalen LRD-Zielfeldern zeigt die Zuordnung außerdem den tatsächlichen Feldtyp (z. B. Ganzzahl, Betrag oder Datum); nur bei neu anzulegenden Custom-Feldern ist der Typ frei wählbar.

## CSV-Import (`Strg+I`)

Der Importassistent bietet:

- automatische Erkennung von UTF-8/Windows-1252 und Trennzeichen,
- Vorschau der Quelldatei vor dem Import,
- automatische Feldzuordnung über deutsche/englische Bezeichnungen und bekannte Altbezeichnungen,
- vollständig manuelle Zuordnung per Maus über jede CSV-Spalte,
- unbekannte CSV-Spalten können direkt als neue Custom-Felder übernommen werden, inklusive Typwahl,
- speicherbare Importprofile für wiederkehrende Fremdformate,
- drei Duplikatstrategien: immer neu, überspringen oder vorhandenen Datensatz aktualisieren,
- frei wählbare Vergleichsfelder für die Duplikaterkennung,
- Option, ob leere Importwerte bestehende Werte löschen dürfen,
- Testlauf über die vollständige Datei, bevor Daten geschrieben werden,
- optionales vollständiges SQLite-Backup vor dem Import,
- Importprotokoll unter `Logs\import_*.log`.

Mehrzeilige CSV-Felder, darunter Memo/Langbeschreibung, werden nach CSV-Standard unterstützt. Beträge akzeptieren deutsche und englische Schreibweise; Datumswerte akzeptieren u. a. `TT.MM.JJJJ` und `JJJJ-MM-TT`.

### CSV-Export (`Strg+E`)

Der Exportassistent erlaubt:

- alle Datensätze oder nur die aktuelle Suche/Filtermenge,
- freie Auswahl und Reihenfolge der Exportspalten, einschließlich Custom-Feldern,
- UTF-8 mit BOM, UTF-8 oder Windows-1252,
- Semikolon, Komma, Tabulator oder Pipe als Trennzeichen,
- deutsche, englische oder interne Feldnamen als Spaltenüberschriften,
- neutrales Austauschformat (`YYYY-MM-DD`, Dezimalpunkt) oder das aktuelle Anzeigeformat,
- Vorschau vor dem Schreiben,
- speicherbare Exportprofile.

CSV ist damit zugleich das vorgesehene Austauschformat für das später getrennte private MDB-Migrationswerkzeug. Vollständige LRD-Sicherungen bleiben dagegen SQLite-Backups.

**Der MDB-Migrator ist ab v0.7.6 nicht mehr Bestandteil des LRD-Quellpakets.** Das private Werkzeug `LRD_MDB_to_CSV_Private` wird separat aufbewahrt und erzeugt eine neutrale CSV, die über den normalen LRD-Import eingelesen wird. Dadurch enthält die spätere Freeware weder `pyodbc` noch MDB-/Jet-Code.







## v0.7.5 Beta – Entwicklungsstatus und Windows SmartScreen

LRD befindet sich weiterhin in Entwicklung. Solange dieser Entwicklungsstatus besteht, wird die sichtbare Programmversion als **`0.7.5 Beta`** angezeigt. Die rein numerische Dateiversion bleibt intern `0.7.5`, weil Windows- und Nuitka-Versionsressourcen eine numerische Versionsangabe benötigen. Der Zusatz **Beta** wird zentral aus `musicdb/version.py` erzeugt.

### Hinweis zu Windows Defender SmartScreen

Die derzeitigen LRD-Beta-EXE-Dateien besitzen **noch kein Code-Signing-Zertifikat und sind daher nicht digital signiert**. Bei einer aus dem Internet heruntergeladenen, unbekannten EXE kann Windows Defender SmartScreen deshalb beim ersten Start beispielsweise melden:

> Windows hat Ihren PC geschützt
> Microsoft Defender SmartScreen hat den Start einer unbekannten App verhindert.

Diese Warnung bedeutet nicht automatisch, dass LRD Schadsoftware enthält. SmartScreen bewertet unter anderem die Signatur und die bisherige Reputation einer heruntergeladenen Datei. Eine neue, nicht signierte Programmversion beginnt ohne etablierte Reputation.

Wenn Sie LRD aus der von Dietmar Steffen bereitgestellten, vertrauenswürdigen Originalquelle bezogen haben und die Datei bewusst starten möchten, ist bei der normalen SmartScreen-Warnung üblicherweise folgender Weg möglich:

1. Im SmartScreen-Fenster **Weitere Informationen** wählen.
2. Dateiname und angezeigte Informationen prüfen.
3. **Trotzdem ausführen** wählen.

Die genaue Beschriftung kann je nach Windows-Version und Sprache geringfügig abweichen. **SmartScreen sollte nicht global deaktiviert werden**, nur um LRD zu starten.

Auf manchen Windows-11-Systemen kann **Smart App Control** oder eine Unternehmensrichtlinie die Ausführung unbekannter, nicht signierter Programme vollständig blockieren; dann wird möglicherweise kein „Trotzdem ausführen“ angeboten. In diesem Fall sollte die Sicherheitsrichtlinie nicht allein für LRD abgeschaltet werden. Für spätere öffentliche Releases kann eine digitale Codesignatur geprüft werden.

Vor jeder öffentlichen Veröffentlichung wird außerdem sichergestellt, dass das Paket keine persönliche Datenbank, Backups, Passwörter oder privaten Migrationsdaten enthält.

## v0.7.4 – automatische und manuelle SQLite-Sicherungen

LRD besitzt jetzt eine integrierte vollständige Datensicherung. `Strg+B` bzw. `Programm -> Jetzt sichern` erstellt eine manuelle Sicherung. Manuelle Sicherungen werden niemals automatisch gelöscht. `Strg+Umschalt+B` öffnet die Sicherungsverwaltung; dort können Sicherungen ausdrücklich ausgewählt und gelöscht werden. `Strg+Alt+B` öffnet die Backup-Einstellungen.

Automatische Sicherungen können beim Beenden von LRD erstellt werden. Standardmäßig sind sie aktiviert und werden 30 Tage aufbewahrt. Die Rotation richtet sich ausschließlich nach dem Alter: Nur `auto_*.sqlite`, deren Änderungszeitpunkt die eingestellte Aufbewahrungsdauer überschritten hat, werden gelöscht. `manual_*.sqlite` bleiben unabhängig vom Alter bestehen.

Der bevorzugte Standardordner ist `Backups` direkt neben `LRD.exe`. Kann LRD dort nicht schreiben, wird automatisch `%LOCALAPPDATA%\LRD\Backups` verwendet. Ein eigener Sicherungsordner kann eingestellt werden. Die Sicherung erfolgt über die SQLite-Backup-API und jede erzeugte Datei wird anschließend mit `PRAGMA integrity_check` geprüft.

Die frühere automatische `before_edit`-Sicherung beim ersten Ändern eines Programmlaufs wurde entfernt; die Datensicherung wird ab dieser Version ausschließlich über das zentrale Backup-System gesteuert. Für v0.7.4 ist keine erneute Datenmigration notwendig.


## v0.7.3 – Benutzerdefinierte Felder

LRD kann jetzt zusätzliche Felder direkt aus der Anwendung heraus verwalten. Unter `Ansicht -> Benutzerdefinierte Felder…` (`Strg+Alt+F`) lassen sich Felder anlegen und bearbeiten. Unterstützte Typen sind Text, Langtext, editierbare Auswahl, Ganzzahl, Betrag und Datum. Für jedes Feld können eine deutsche und eine englische Bezeichnung, Sichtbarkeit auf der Detailmaske, Sichtbarkeit in der Tabelle und Aktiv/Inaktiv festgelegt werden.

Custom-Felder werden nicht als neue Spalten in `records` angelegt, sondern über die bereits vorhandenen Tabellen `custom_fields` und `custom_values` gespeichert. Deshalb ist keine Änderung des bestehenden SQLite-Schemas und keine erneute MDB-Migration erforderlich. Umbenennen oder Deaktivieren erhält die gespeicherten Werte. Der Feldtyp kann nach dem ersten gespeicherten Wert aus Sicherheitsgründen nicht mehr geändert werden.

Custom-Felder sind in der normalen Strg+F-Suche, im Tabellenfilter, in der Spaltenkonfiguration, in der Sortierung und in der direkten Tabellenbearbeitung nutzbar. Editierbare Auswahlfelder beziehen ihre Vorschläge automatisch aus den bereits gespeicherten Werten. Ein eigener scrollbarer Bereich am Ende der Detailansicht verhindert, dass viele Custom-Felder die Hauptmaske überlaufen.

## v0.7.2 – Plattenraum-Bild in der Hauptmaske

- Das LRD-Plattenraum-Bild wird rechts neben der vierzeiligen Langbeschreibung angezeigt.
- Ein Klick auf die Vorschau öffnet eine größere Bildansicht.
- Ein Klick auf das große Bild oder `Esc` schließt die Bildansicht wieder.
- Das Bild bleibt eine feste Programmressource und wird beim Nuitka-Build eingebunden.

## v0.7.1 – Neuer Produktname

Der Produktname lautet ab dieser Version **LRD – Local Record Desk**. Die Windows-EXE wird spaeter `LRD.exe` heissen. Lizenz, Hilfe, Ueber-Dialog und Nuitka-Metadaten verwenden denselben Namen. Die Anwendung ist ausdruecklich als lokale Desktop-Datenbank konzipiert: keine Cloud, kein Benutzerkonto und keine Telemetrie fuer die normale Datenpflege.

Das vom Rechteinhaber bereitgestellte KI-erstellte Plattenraum-Bild ist unter `assets/record_room.png` bereits als feste Programmressource enthalten. Die sichtbare Position in der GUI wird spaeter festgelegt.

Fuer diese Version ist keine erneute Migration erforderlich.

## Lokal statt Cloud

LRD ist als klassische Windows-Desktop-Anwendung ausgelegt. Die Sammlungsdaten liegen lokal in der SQLite-Datei auf dem eigenen Rechner. Fuer die normale Datenpflege sind weder Cloud-Speicher noch Benutzerkonto oder Internetverbindung erforderlich. LRD enthaelt keine Telemetrie fuer die normale Datenpflege und uebertraegt die Sammlung nicht automatisch an externe Dienste. Spaetere optionale Online-Funktionen muessen vom Anwender ausdruecklich gestartet werden.


## v0.7.0 – Windows-typische Strg-Tastaturkürzel

Die Hauptbedienung verwendet nun mnemonische Strg-Kürzel statt der bisherigen F2–F8-Belegung. Die wichtigsten Befehle sind `Strg+F` Suchen, `Strg+T` Tabelle ein/aus, `Strg+N` Neu, `Strg+D` Löschen und `Strg+S` Speichern. `Strg+Umschalt+C` öffnet die Spaltenkonfiguration, `Strg+G` den Tabellenfilter. Mit `Strg+Umschalt+F` bzw. `Strg+Umschalt+G` werden Suche bzw. Tabellenfilter aufgehoben. F1 bleibt als Windows-übliche Hilfe-Taste erhalten; Bild↑/Bild↓ und Strg+Pos1/Strg+Ende bleiben für die Datensatznavigation. Menüs, Schaltflächen und Hilfe zeigen dieselben Kürzel an.

Für diese Version ist keine erneute Migration erforderlich.


## Historie: v0.6.9 – frei konfigurierbare Tabelle und damalige F-Tasten-Shortcuts

Die Tabellenansicht ist jetzt dauerhaft konfigurierbar. Unter `Tabelle -> Spalten konfigurieren…` können vorhandene Datenfelder als Spalten hinzugefügt oder entfernt und in eine eigene Reihenfolge gebracht werden. Die Spaltenbreiten bleiben weiterhin direkt am Tabellenkopf veränderbar und werden gespeichert. Die primäre Sortierung kann im selben Dialog gewählt werden; ein Klick auf einen Spaltenkopf sortiert weiterhin direkt auf- bzw. absteigend und zeigt die Sortierrichtung mit einem Pfeil an.

Unter `Tabelle -> Filter…` können beliebige Feldfilter gesetzt werden. Mehrere Filter werden mit UND verknüpft und mit einer eventuell aktiven normalen F4-Suche kombiniert. Textfilter arbeiten als Teiltextsuche und unterstützen `*` / `?`; Zahlen, Preise und Datumsfelder unterstützen Vergleichsoperatoren und Bereiche wie `10..20`. Tabellenfilter werden gespeichert und beim nächsten Start wiederhergestellt.

Die Aktionsschaltflächen zeigen ihre Funktionstasten nun direkt in der lesbareren Form `Suchen (F4)`, `Tabelle ein/aus (F5)`, `Neu (F6)`, `Löschen (F7)` und `Speichern (F8)`. Auch die Menüs verwenden diese Schreibweise. Die Kurzhilfe dokumentiert die Tastaturbedienung vollständig.

Für diese Version ist **keine erneute MDB-Migration notwendig**; das SQLite-Schema bleibt unverändert.


## v0.6.6 – zentrale Version und Nuitka-Vorbereitung

Die Programmversion steht nur noch in `musicdb/version.py`. GUI, Hilfe-Dialog, MDB-Migrator, Migrationsmetadaten und spaetere EXE-Versionsressourcen lesen denselben Wert. `version_check.py` prueft diese Regel automatisch. Als Rechteinhaber ist `Dietmar Steffen` in `LICENSE.txt` festgelegt. Fuer Windows-EXE-Builds ist Nuitka vorgesehen. `build_exe_64bit.bat` erzeugt zunaechst einen Standalone-Build; `build_onefile_64bit.bat` ist fuer die spaetere Ein-Datei-Ausgabe vorgesehen.

`app.py` trennt nun Ressourcen vom beschreibbaren Programm-/Datenverzeichnis, damit eine spaetere Nuitka-Onefile-EXE die SQLite-Datei nicht versehentlich im temporaeren Entpackverzeichnis sucht.

Diese Version ist der technische Schnitt von der alten Jet/Access-MDB zur neuen SQLite-Arbeitsdatenbank.

## Wichtig

Die alte `MUSICDB.MDB` bleibt unverändert. Der MDB-Migrator ist ab jetzt ausdrücklich ein **privates Entwicklungswerkzeug** für die Übernahme des persönlichen Altbestands und wird später nicht mit der öffentlichen Freeware ausgeliefert.

Die Anwendung selbst arbeitet ab v0.6.3 ausschließlich mit `MUSICDB.sqlite`.

## Erster Start

1. Einmal `install_64bit.bat` ausführen; die LRD-Anwendung benötigt keine externen Python-Pakete.
2. `run_64bit.bat` starten.
3. Beim ersten Start entweder **Neue leere Datenbank erstellen…** oder **Vorhandene LRD-Datenbank öffnen…** wählen.
4. Bei einer neuen Datenbank kann der CSV-Import unmittelbar danach gestartet werden.

Eine vorhandene `MUSICDB.sqlite` aus älteren Entwicklungsständen wird weiterhin erkannt. Neue Sammlungen werden standardmäßig als `LRD.sqlite` angelegt.

Für eine erneute persönliche Übernahme der alten MDB wird das separat aufbewahrte Werkzeug **LRD_MDB_to_CSV_Private** verwendet. Dessen CSV wird anschließend über `Daten -> Importieren -> CSV` eingelesen.

## Neues aktives Datenmodell

Standard-Reihenfolge der Hauptmaske:

1. Interpret
2. Titel/Album
3. Label
4. Katalognummer
5. Barcode (neu)
6. Jahr
7. Land
8. DT-Art
9. Bestand (aus Stück)
10. Unterart (neu)
11. Musikrichtung
12. Preis
13. Kommentar
14. Memo/Langbeschreibung (`Memotext1`), permanent sichtbar und vierzeilig
15. Zustand DT
16. Zustand Label (aus `DTLabelArt` / Label DT)
17. Zustand Cover
18. Art Cover
19. Status (aus `Wastundamit`)
20. Eigene Rechnungsnummer Verkauf (aus `Allgemein`, künftig normales Textfeld)
21. Rechnungsnummer Einkauf (neu)
22. Discogs ID (aus `Auktionsnummer`)
23. Eigene Inventarnummer (aus `Bestellnr`)
24. Matrixnummer (neu)
25. Presswerk (neu)

Zunächst am Ende der Detailmaske:

- EK-Preis
- VK-Preis
- Kaufdatum
- Wo gekauft?
- Stellplatz

Nicht mehr aktive Alt-Felder werden nicht in der neuen `records`-Tabelle geführt, bleiben bei der Migration aber in `legacy_music_extra` erhalten. Kleinere Nebentabellen der MDB werden als `legacy__<Tabellenname>` kopiert. Damit gehen bei späteren Erweiterungen keine derzeit ignorierten Altinformationen verloren.

## Bedienung

- Felder sind im normalen Modus immer direkt editierbar.
- Beim Weiterblättern wird automatisch gespeichert, wenn etwas geändert wurde.
- `Strg+S` speichert sofort.
- `Strg+N` legt einen neuen Datensatz an.
- `Strg+D` löscht den aktuellen Datensatz nach Rückfrage.
- `Strg+F` schaltet in den Suchmodus. Kriterien können in **allen sichtbaren Feldern einschließlich Auswahlboxen und Memo** kombiniert werden. Nochmal `Strg+F` führt die Suche aus.
- `Strg+T` bzw. **Tabelle ein/aus** schaltet die untere Hälfte zwischen Detailfeldern und Tabellenansicht um.
- Das Grid ist editierbar: Doppelklick auf eine Zelle, Wert ändern, Enter/Tab oder Fokuswechsel speichert.

## Auswahlboxen

Die editierbaren Auswahlboxen werden direkt aus den vorhandenen Werten der SQLite-Daten aufgebaut. Freie Eingabe bleibt möglich. Ein neuer gespeicherter Wert erscheint danach automatisch als Auswahlwert.

Betroffen sind zunächst:

- Land
- DT-Art
- Unterart
- Musikrichtung
- Zustand DT
- Zustand Label
- Zustand Cover
- Art Cover
- Status

## Deutsch / Englisch

Oben rechts sowie über `Ansicht -> Sprache` kann zwischen Deutsch und English umgeschaltet werden. Die Datenbankspalten ändern sich dadurch nicht; nur GUI, Menüs und Tabellenüberschriften werden übersetzt. Die gewählte Sprache wird gespeichert.

## Wiederherstellung des letzten Zustands

In `app_settings` werden automatisch gespeichert:

- Fenstergröße und -position
- zuletzt gewählte Sprache
- Detail-/Grid-Ansicht
- zuletzt angezeigter Datensatz
- Grid-Sortierung
- Grid-Spaltenbreiten

Beim nächsten Start wird dieser Zustand wiederhergestellt.

## Für spätere Erweiterungen bereits vorgesehen

Das SQLite-Schema enthält bereits:

- `ui_field_layout` für Reihenfolge, Sichtbarkeit und Grid-Einstellungen der festen Felder
- `custom_fields` für frei definierbare zusätzliche Felder
- `custom_values` für deren Werte

Die Tabellen-Spalten können ab v0.6.9 bereits frei ein-/ausgeblendet und angeordnet werden. Benutzerdefinierte Felder können ab v0.7.3 direkt in LRD angelegt und verwaltet werden. Die spätere freie Anordnung der gesamten Hauptmaske bleibt als weitere Ausbaustufe vorgesehen.

## Sicherungen

Die laufende Anwendung verwendet das zentrale Backup-System aus v0.7.4: automatische Sicherung beim Beenden (optional), manuelle Sicherung auf Anforderung, frei einstellbare Aufbewahrungsdauer für automatische Backups und ein konfigurierbarer Sicherungsordner. Manuelle Sicherungen werden nie automatisch gelöscht.

Der private MDB-Migrator kann weiterhin eigene Entwicklungssicherungen anlegen; diese Funktion gehört nicht zur späteren öffentlichen Freeware.

## Hinweis zum MDB-Passwort

Das öffentliche LRD-Paket enthält weder MDB-Passwort noch MDB-Konfiguration. Persönliche MDB-Zugangsdaten gehören ausschließlich in das separat aufbewahrte private MDB→CSV-Werkzeug.


## v0.6.3 – Migrationskorrektur

- Fehleranzeige im Migrator korrigiert (Tkinter/Exception-Closure).
- Alte Jet/ODBC-Texte mit ungültigen UTF-16-Surrogaten werden robust normalisiert.
- Gültige Surrogatpaare werden korrekt zu Unicode-Zeichen zusammengesetzt; einzelne ungültige Codeeinheiten werden durch U+FFFD ersetzt.
- Fundstellen werden im Protokoll gemeldet und in `migration_warnings` dokumentiert.

Zusätzlich verwendet der Migrator für alte Jet-Dateien bewusst **nicht** `pyodbc.cursor.columns()`. Manche Access-97-Dateien enthalten in nicht benötigten ODBC-Metadatenfeldern ungültiges UTF-16. Die Spaltenstruktur wird daher über eine Nullzeilen-Abfrage (`SELECT * FROM [Tabelle] WHERE 1=0`) gelesen, was diese problematischen Metadaten umgeht und mit dem alten Jet-Treiber kompatibel ist.

## v0.6.3 – Bedienung / Tabellenansicht

- `Bild ↑` / Page Up: vorheriger Datensatz
- `Bild ↓` / Page Down: nächster Datensatz
- Die doppelte Anzeige „Eigene Datenbank / My database“ und die interne ID wurden aus dem Kopfbereich entfernt.
- Die Tabellenansicht zeichnet nun sichtbare horizontale und vertikale Trennlinien zwischen Datensätzen und Zellen.
- Tabellenzellen bleiben per Doppelklick editierbar.
- Spalten können weiterhin am Tabellenkopf in der Breite verändert werden.
- F5 bzw. der Schalter heißt jetzt dynamisch `Tabelle ein` / `Tabelle aus` bzw. `Table on` / `Table off`.


## v0.6.4 – Hilfe und Lizenzvorbereitung

Neu im Hauptmenü **Hilfe**:

- Kurzhilfe / Quick help
- Lizenz / License
- Drittanbieter-Lizenzen / Third-party licenses
- Über LRD - Local Record Desk / About LRD - Local Record Desk

Die zugehörigen Texte liegen als normale Dateien im Projekt (`HELP_de.txt`, `HELP_en.txt`, `LICENSE.txt`, `THIRD_PARTY_NOTICES.txt`, `licenses\...`) und werden auch beim Nuitka-Build eingebunden.

### Lizenzprüfung für eine spätere Freeware-Veröffentlichung

Aktuell geprüft und dokumentiert sind Python/CPython, Tcl/Tk, SQLite und Nuitka. Das separate private MDB→CSV-Werkzeug verwendet zusätzlich pyodbc unter MIT-0. Der Microsoft Access/Jet-ODBC-Treiber wird **nicht** mitgeliefert; eine spätere Bündelung eines Microsoft-Redistributables müsste separat geprüft werden.

`check_licenses.bat` führt eine Entwicklungsprüfung aus. Die eigene `LICENSE.txt` ist ab v0.6.5 als klassische Freeware-Lizenz festgelegt. Vor einer öffentlichen Version müssen persönliche Datenbanken, Backups und Passwörter aus dem Paket bleiben. Das private MDB→CSV-Werkzeug ist bereits separat.

### Persönliches MDB-Passwort

LRD selbst enthält kein MDB-Passwort. Eine eventuelle private Passwortkonfiguration befindet sich ausschließlich im separaten MDB→CSV-Werkzeug und darf nicht veröffentlicht werden.


## v0.6.5 – Freeware-Lizenz und Trennung der Migration

LRD - Local Record Desk ist als klassische Freeware vorgesehen: kostenlose private und geschäftliche Nutzung, kostenlose unveränderte Weitergabe des vollständigen Originalpakets, kein Verkauf und keine Veröffentlichung veränderter Versionen ohne schriftliche Genehmigung. Die Details stehen in `LICENSE.txt`.

Der frühere MDB→SQLite-Migrator wurde ab v0.7.6 aus dem LRD-Quellpaket entfernt. Für die persönliche Altbestandsübernahme existiert ein separates MDB→CSV-Werkzeug; LRD selbst benötigt weder `pyodbc` noch Microsoft-Access-/Jet-Treiber.

Spätere Import- und Exportfunktionen sind davon getrennt. Sie werden als reguläre Anwenderfunktionen in LRD - Local Record Desk vorgesehen. Dabei sollten mindestens ein vollständiges verlustfreies Austausch-/Backupformat sowie tabellarische Formate für den Datenaustausch vorgesehen werden; die konkreten Formate legen wir später fest.


## Änderungen in 0.6.9

- Vollständige Tastatursteuerung der Hauptfunktionen.
- F2: Tabellenspalten konfigurieren.
- F3: Tabellenfilter öffnen; Umschalt+F3: Tabellenfilter aufheben.
- F4: Suche; Umschalt+F4: Suche aufheben.
- F5 bis F8: Tabelle, Neu, Löschen, Speichern.
- Strg+Q: Beenden; Strg+Alt+D/E: Sprache Deutsch/English.
- F1/Umschalt+F1/Strg+F1/Alt+F1: Hilfe, Lizenz, Drittanbieter-Lizenzen, Über.
- Beim Wiederherstellen des letzten Datensatzes bleibt nach Möglichkeit eine Kontextzeile oberhalb sichtbar.

## Startdiagnose

Beim ersten Start zeigt LRD ein sichtbares Startfenster mit den Optionen, eine neue Datenbank anzulegen oder eine vorhandene zu öffnen. Falls LRD bereits vor der Hauptoberfläche scheitert, wird automatisch `LRD_startup_error.log` erzeugt (bevorzugt im Programmordner, sonst unter `%LOCALAPPDATA%\LRD`). Diese Datei enthält die technische Fehlermeldung für die Diagnose.


## Python-Auswahl ab v0.7.11 Beta

LRD benoetigt kein bestimmtes Python-3.13-Release. Die Start- und Build-Skripte suchen automatisch nach einem installierten 64-Bit-Python in der Reihenfolge 3.13, 3.12, 3.11, 3.10. Ein parallel installiertes 32-Bit-Python wird ignoriert.

Auf einem Rechner mit z. B. `Python 3.13 32 Bit` und `Python 3.11 64 Bit` verwendet LRD automatisch Python 3.11 64 Bit. Der private MDB-zu-CSV-Konverter kann weiterhin separat Python 32 Bit verwenden.


## GitHub Portable Release

Der öffentliche Portable-Download wird nach einem erfolgreichen Nuitka-Onefile-Build mit `package_portable.py` bzw. `package_portable_64bit.bat` erzeugt. `build_onefile_64bit.bat` ruft diesen Schritt automatisch auf. Das Ergebnis liegt unter `release\LRD-v<Version>-Beta-x64-Portable.zip` und enthält ausschließlich `LRD.exe`, Dokumentation, Lizenzhinweise, `portable.flag` und `SHA256SUMS.txt` – keine persönliche Datenbank oder Backups.
